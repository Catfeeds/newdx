<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// Route::get('/', 'WelcomeController@index');

// Route::get('home', 'HomeController@index');

// Route::controllers([
// 	'auth' => 'Auth\AuthController',
// 	'password' => 'Auth\PasswordController',
// ]);
//Route::get('api_forum/home','apiforum\api_userLoginController@home');//热贴测试


Route::get('/', 'apiforum\api_userLoginController@index');

Route::get('api_forum/userLogin','apiforum\api_userLoginController@userLogin');//微信用户登录

Route::get('api_forum/home_list','apiforum\api_userLoginController@home_list');//首页列表帖
Route::get('api_forum/forum_list','apiforum\api_userLoginController@forum_list');//列表帖子
Route::get('api_forum/forum_list2/{fid}','apiforum\api_userLoginController@forum_list2');//列表帖子


Route::get('api_forum/classifyAll','apiforum\api_userLoginController@classifyAll');//获取全部分类


Route::get('api_forum/videoList','apiforum\api_userLoginController@videoList');//视频列表
Route::get('api_forum/videoMore/{id}','apiforum\api_userLoginController@videoMore');//视频列表
Route::any('api_forum/videoComments_put', 'apiforum\api_userLoginController@videoComments_put');//视频评论提交
Route::any('api_forum/videoComments_get', 'apiforum\api_userLoginController@videoComments_get');//视频评论查询




Route::any('api_forum/userPublish', 'apiforum\api_userPostedController@userPublish');//用户发帖
Route::any('api_forum/userImg', 'apiforum\api_userPostedController@userImg');//用户发帖
Route::any('api_forum/testMakeDir', 'apiforum\api_userPostedController@testMakeDir');//用户发帖图片上传
Route::any('api_forum/userReply', 'apiforum\api_userPostedController@userReply');//用户回帖


/*
 * 用户中心
 * */
Route::get('api_forum/userPost', 'apiforum\api_myController@userPost');//查看用户发的帖子
Route::get('api_forum/myPost', 'apiforum\api_myController@myPost');//用户中心我发的帖子
Route::get('api_forum/myFavorite', 'apiforum\api_myController@myFavorite');//我的收藏
Route::get('api_forum/myFavorite_put', 'apiforum\api_myController@myFavorite_put');//点击收藏

Route::get('api_forum/myFootprint', 'apiforum\api_myController@myFootprint');//我的足迹
Route::get('api_forum/myFootprint_put', 'apiforum\api_myController@myFootprint_put');//帖子足迹请求
Route::get('api_forum/lookUserInfo', 'apiforum\api_myController@lookUserInfo');//足迹请求


Route::get('api_forum/pre_forum_post/{tid}', 'apiforum\api_userLoginController@pre_forum_post');//帖子详情测试

Route::any('api_forum/yunImg/', 'apiforum\api_userPostedController@yunImg');//图片上传


Route::get('api_forum/myfollow_put', 'apiforum\api_myController@myfollow_put');//查看用户发的帖子
Route::get('api_forum/myfollow', 'apiforum\api_myController@myfollow');//我关注的人
Route::get('api_forum/userfollow', 'apiforum\api_myController@userfollow');//关注我的人
Route::get('api_forum/userfollow_del', 'apiforum\api_myController@userfollow_del');//用户取消关注


Route::get('api_forum/myForum_get', 'apiforum\api_userLoginController@myForum_get');//定义我的栏目
Route::any('api_forum/myForum_put', 'apiforum\api_userLoginController@myForum_put');//定义我的板块
Route::get('api_forum/myForum_del', 'apiforum\api_userLoginController@myForum_del');//定义我的栏目






