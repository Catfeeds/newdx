<?php

namespace App\Http\Controllers\apiforum;

use App\Http\Controllers\Controller;
use App\Http\Models\Common_member_connect_wechat;//微信登陆模型
use Illuminate\Http\Request;
use App\Http\Requests;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Cache;//加载缓存
class api_myController extends Controller
{


    /*数据库变更说明：
    1、common_member_connect_wechat  openid 字段长度变为64
    2、增加头像存储字段avatarurl 长度200
    3、增加足迹记录表common_member_my_footprint
    4、增加视频评论表pre_exam_video_comments
    5、增加自定义栏目表my_forum
     *
     *
     * */

    /*
        * 我发布的
        * */
    public function myPost(Request $request)
    {
        if ($request->unionid) {
            $user = Common_member_connect_wechat::where('unionid', $request->unionid)->first();
            $uid = $user->uid;
            return ['myList' => $this->forum_thread($uid)];
        } else {
            return "参数错误!";
        }
    }


    /*
    * 用户发布的帖子
    * */
    public function userPost(Request $request)
    {
        if ($request->authorid) {
            return ['userList' => $this->forum_thread($request->authorid)];
        } else {
            return "参数错误！";
        }
    }


    //公用
    public function forum_thread($uid)
    {
        $data = DB::table('forum_thread')->where('authorid', $uid)
            ->leftJoin('forum_post_previewimg', 'forum_post_previewimg.tid', '=', 'forum_thread.tid')
            ->leftJoin('forum_forum', 'forum_forum.fid', '=', 'forum_thread.fid')
            ->select(
                'forum_thread.subject',
                'forum_thread.tid',
                'forum_thread.views',
                'forum_thread.lastpost',
                'forum_forum.name',
                'forum_post_previewimg.image'
            )
            ->orderBy('forum_thread.lastpost', 'desc')
            ->paginate(6);
        foreach ($data as $key => $value) {
            $value->image = json_decode(stripslashes($value->image), true);
            $value->n = date('Y-m', $value->lastpost);
            $value->y = date('d', $value->lastpost);
        }
        return $data;
    }


    /*
     * 帖子收藏请求
     *
     * */
    public function myFavorite_put(Request $request)
    {
        //return $data = Input::all();
        if ($request->unionid) {
            $user = Common_member_connect_wechat::where('unionid', $request->unionid)->first();
            $favorite = DB::table('home_favorite')->where('uid', $user->uid)->get();
            foreach ($favorite as $key) {
                $id = $key->id;
                if ($id == $request->tid) {
                    return ['data' => true, 'error' => "该帖子已收藏过！"];
                }
            }

            $info = DB::connection('mysql2')->table('home_favorite')->insert(
                [
                    'uid' => $user->uid,
                    'id' => $request->tid,
                    'pid' => 0,//帖子id
                    'idtype' => 'tid',//板块id
                    'title' => mb_convert_encoding($request->subject, "GBK"),//帖子内容
                    'dateline' => time(),//时间
                    'description' => 0,
                    'is_mark' => $request->is_mark,
                ]);

            if ($info) {
                return ['data' => true, 'error' => "收藏成功！"];
            } else {
                return ['data' => false, 'error' => "收藏失败！"];
            }
        } else {
            return "参数错误!";
        }
    }


    /*
     * 我收藏的帖子
     * */
    public function myFavorite(Request $request)
    {
        if ($request->unionid) {
            $user = Common_member_connect_wechat::where('unionid', $request->unionid)->first();
            $data = DB::table('home_favorite')->where('uid', $user->uid)
                ->leftJoin('forum_thread', 'forum_thread.tid', '=', 'home_favorite.id')
                ->leftJoin('forum_forum', 'forum_forum.fid', '=', 'forum_thread.fid')
                ->leftJoin('forum_post_previewimg', 'forum_post_previewimg.tid', '=', 'forum_thread.tid')
                ->select(
                    'home_favorite.is_mark',
                    'home_favorite.id',
                    'home_favorite.title',
                    'forum_thread.author',
                    'forum_forum.name',
                    'forum_thread.views',
                    'forum_post_previewimg.image'
                )
                ->orderBy('forum_thread.dateline', 'desc')
                ->paginate(6);
            foreach ($data as $key => $value) {
                $value->image = json_decode(stripslashes($value->image), true);
            }
            return ['myFavorite' => $data];

        } else {
            return "参数错误!";
        }
    }


    /*
     * 足迹请求
     *
     * */
    public function myFootprint_put(Request $request)
    {
        if ($request->unionid) {
            DB::table('forum_thread')->where('tid', $request->tid)->increment('views');//浏览次数
            $user = Common_member_connect_wechat::where('unionid', $request->unionid)->first();
            $favorite = DB::table('common_member_my_footprint')->where('uid', $user->uid)->get();
            foreach ($favorite as $key) {
                $tid = $key->tid;
                if ($tid == $request->tid) {
                    return ['data' => true, 'error' => "已记录过!"];
                    exit();
                }
            }
            $info = DB::table('common_member_my_footprint')->insert(
                [
                    'uid' => $user->uid,
                    'tid' => $request->tid,
                    'time' => time(),
                ]);

            if ($info) {
                return ['data' => true, 'error' => "足迹记录成功！"];
            } else {
                return ['data' => false, 'error' => "足迹记录失败！"];
            }
        } else {
            return "参数错误!";
        }
    }

    /*
     *
     * 我的足迹
     *
     * */

    public function myFootprint(Request $request)
    {
        $time = time();
        $times = $time - 86400 * 30;
        if ($request->unionid) {
            $user = Common_member_connect_wechat::where('unionid', $request->unionid)->first();
            $data = DB::table('common_member_my_footprint')->where('uid', $user->uid)
                ->leftJoin('forum_thread', 'forum_thread.tid', '=', 'common_member_my_footprint.tid')
                ->leftJoin('forum_post_previewimg', 'forum_post_previewimg.tid', '=', 'forum_thread.tid')
                ->where('common_member_my_footprint.time', '>=', $times)//查询30天内的
                ->select(
                    'forum_thread.subject',
                    'forum_thread.tid',
                    'forum_thread.author',
                    'forum_thread.views',
                    'forum_post_previewimg.image',
                    'forum_thread.authorid'
                )
                ->orderBy('common_member_my_footprint.time', 'desc')
                ->paginate(6);

            foreach ($data as $key => $value) {
                $value->image = json_decode(stripslashes($value->image), true);
            }

            return ['myFootprint' => $data];
        } else {
            return "参数错误!";
        }
    }


    /*
     * 关注请求
     *
     * */

    public function myfollow_put(Request $request)
    {

        $user = Common_member_connect_wechat::where('unionid', $request->unionid)->first();
        $follow = DB::table('home_follow_0')->where('fwuid', $user->uid)->get();
        foreach ($follow as $key) {
            $uid = $key->uid;
            if ($uid == $request->authorid) {
                return ['data' => true, 'error' => "已关注过!"];
                exit();
            }
        }

        $info = DB::connection('mysql2')->table('home_follow_0')->insert
        ([
            'uid' => $request->authorid,//用户ID
            'fwuid' => $user->uid,//	my唯一用户名
            'fwusername' => mb_convert_encoding($request->author, "GBK"),//被关注用户名称
            'gid' => 1,
            'intimacy' => 1,
            'nickname' => 0,
            'dateline' => time(),
        ]);

        if ($info) {
            return ['data' => true, 'error' => "关注成功！"];
        } else {
            return ['data' => false, 'error' => "关注失败！"];
        }

    }


    /*
     * 我关注的
     *
     * */

    public function myfollow(Request $request)
    {
        if ($request->unionid) {
            $user = Common_member_connect_wechat::where('unionid', $request->unionid)->first();
            $data = DB::table('home_follow_0')->where('fwuid', $user->uid)->where('mutual', 1)
                ->select(
                    'uid',
                    'fwuid',
                    'fwusername',
                    'mutual'//是否相互关注1单向2双向
                )
                ->orderBy('dateline', 'desc')
                ->paginate(6);

            return ['myfollow' => $data];
        } else {

            return "参数错误！";
        }

    }


    /*
     *
     * 关注我的人
     *
     * */

    public function userfollow(Request $request)
    {
        if ($request->unionid) {
            $user = Common_member_connect_wechat::where('unionid', $request->unionid)->first();
            $data = DB::table('home_follow_0')->where('uid', $user->uid)
                ->select(
                    'uid',
                    'fwuid',
                    'fwusername',
                    'mutual'
                )
                ->orderBy('dateline', 'desc')
                ->paginate(6);

            if ($data->first()) {
                return ['userfollow' => $data];
            } else {
                return ['data' => true, 'error' => "暂时没人关注你哦!"];
            }

        } else {
            return "参数错误";
        }
    }


    /*
     * 用户取消关注
     * */
    public function userfollow_del(Request $request)
    {
        DB::table('home_follow_0')
            ->where('fwuid', $request->fwuid)
            ->where('uid', $request->uid)->delete();
        return ['data' => 0, 'error' => "取消成功！"];
    }


}
