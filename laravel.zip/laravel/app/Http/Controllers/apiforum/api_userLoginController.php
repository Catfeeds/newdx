<?php

namespace App\Http\Controllers\apiforum;
use App\Http\Controllers\Controller;
use App\Http\Models\Common_member_connect_wechat;
use Illuminate\Http\Request;
use App\Http\Requests;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Cache;//加载缓存

class api_userLoginController extends Controller
{
    /*
     * 微信用户登录 ,及用户绑定流程
     * */
    public function userLogin()
    {
        //调用模型里方法用户登录方法
        $model = new Common_member_connect_wechat;
        if (false !== $userInfo = $model->login()) {

            if (($user = $model->isLogin($userInfo['unionId'])) !== null) {
                //用户信息更新
                if ($user->avatarurl != $userInfo['avatarUrl'] || 'ohR_' . $user->openid != 'ohR_' . $userInfo['openId'] || $user->nickname != $userInfo['nickName']) {
                    DB::connection('mysql2')->table('common_member_connect_wechat')->where('unionid', $userInfo['unionId'])
                        ->update(['openid' => 'ohR_' . $userInfo['openId'],
                            'avatarurl' => $userInfo['avatarUrl'],
                            'nickname' => mb_convert_encoding($userInfo['nickName'], "GBK")
                        ]);
                }
                return $user->geuUer($user->uid);
            }
            return $model->createUser($userInfo);
        }
        return [];
    }

    /*
     * pre_forum_thread主题数据表
     * common_forum_recommend_wap帖子图片表
     *
     * */
//首页头贴
    public function home_one()
    {
        $array = DB::table('forum_thread')
            ->leftJoin('common_forum_recommend_wap', 'forum_thread.tid', '=', 'common_forum_recommend_wap.tid')
            ->leftJoin('forum_post_previewimg', 'forum_post_previewimg.tid', '=', 'forum_thread.tid')
            ->where('common_forum_recommend_wap.optype', 1)->get();
        foreach ($array as $key => $value) {
            $data[0]['tid'] = $value->tid;
            $data[0]['subject'] = $value->subject;
            $data[0]['views'] = $value->views;
            $data[0]['img'] = json_decode(stripslashes($value->image), true);
        }
        return $data;
    }


    /*首页精华帖
     * pre_common_share
     * pre_common_share_coupon
     *
     * */

    public function home_list()
    {
        $time = time();
        $times = $time - 86400 * 30;
        $data = DB::table('forum_thread')
            ->leftJoin('forum_post_previewimg', 'forum_post_previewimg.tid', '=', 'forum_thread.tid')
            ->leftJoin('forum_forum', 'forum_forum.fid', '=', 'forum_thread.fid')
            ->where('forum_thread.dateline', '>=', $times)//查询30天内的
            ->where('forum_thread.displayorder', '>=', 0)
            ->where('forum_thread.stickreply', 0)
            ->where('forum_thread.digest', '>', 0)
            ->select('forum_thread.authorid', 'forum_thread.tid', 'forum_thread.subject',
                'forum_forum.name',
                'forum_thread.author',
                'forum_thread.views',
                'forum_thread.lastpost',
                'forum_post_previewimg.image')
            ->orderBy('forum_thread.replies', 'desc')
            ->orderBy('forum_thread.dateline', 'desc')
            ->orderBy('forum_thread.heats', 'desc')
            ->orderBy('forum_thread.lastpost', 'desc')
            ->paginate(10);

        foreach ($data as $key => $value) {
            $value->image = json_decode(stripslashes($value->image), true);
            $value->subject = mb_substr($value->subject, 0, 25, 'utf-8') . '...';
        }

        $home_list_data = ['home_one' => $this->home_one(), 'home_list' => $data];
        //加入到缓存
        Cache::put('home_list_data', $home_list_data, 3600);
        if (Cache::has('home_list_data')) {
            return Cache::get('home_list_data');//读取
        }
    }


    /*
     * 帖子列表
     *
     * pre_home_follow_feed 被关注者事件表
     * pre_forum_moderator 版主表
     *
     * pre_forum_forumrecommend版主推荐数据表
     * pre_forum_access 访问权限表
     *
     * forum_viewthread.php参考
     * */


//获得选择的分类
    public function classifyAll()
    {
        $data = DB::table('forum_forum')->where('status', 1)
            ->whereIn('fid', [52, 39, 38, 180, 7, 12, 17, 24, 53, 88, 161])
            ->select('fid', 'name')->get();
        return ['classifyAll' => $data];
    }


    /*
     * 用户栏目定义请求
     * */
    public function myForum_put(Request $request)
    {
        if ($request->unionid) {
            $input = json_decode(Input::get('add_label'), true);
            $user = Common_member_connect_wechat::where('unionid', $request->unionid)->first();

            $favorite = DB::table('my_forum')->where('uid', $user->uid)->get();
            foreach ($favorite as $key) {
                $fid = $key->fid;
                if ($fid == $input['fid']) {
                    return ['data' => true, 'error' => "该栏目已设置过！"];
                }
            }
            $info = DB::connection('mysql2')->table('my_forum')->insert(
                [
                    'uid' => $user->uid,
                    'fid' => $input['fid'],
                    'name' => mb_convert_encoding($input['name'], "GBK"),
                    'time' => time(),
                ]);

            if ($info) {
                return ['data' => true, 'error' => "栏目设置成功！"];
            } else {
                return ['data' => false, 'error' => "栏目设置失败！"];
            }

        } else {
            return "参数错误！";
        }

    }


    /*
     * 获取用户定义的栏目
     * */
    public function myForum_get(Request $request)
    {
        if ($request->unionid) {
            $user = Common_member_connect_wechat::where('unionid', $request->unionid)->first();
            $data = DB::table('my_forum')->where('uid', $user->uid)->get();//用户定义的栏目
            return ['myForum_get' => $data];
        } else {
            return "参数错误！";
        }
    }


    /*
     * 用户删除定义的栏目
     * */
    public function myForum_del(Request $request)
    {
        if ($request->unionid) {
            $input = json_decode(Input::get('del_label'), true);
            DB::table('my_forum')->where('uid', $input['uid'])->where('id', $input['id'])->delete();
            return ['data' => true, 'error' => "删除成功！"];
        } else {
            return "参数错误!";
        }
    }


    public function forum($unionid)
    {
        $user = Common_member_connect_wechat::where('unionid', $unionid)->first();
        $data = DB::table('my_forum')->where('uid', $user->uid)->orderBy('time', 'desc')->get();//用户定义的栏目
        foreach ($data as $key => $value) {
            $f = $fid[0] = $value->fid;
        }
        return $fid = !empty($f) ? $f : 12;
    }


    /*
     * 论坛版块列表及用户自定义列表
     * */
    public function forum_list()
    {
        $input = Input::all();
        $unionid = $input['unionid'];
        if ($this->forum($unionid) == 12) {
            $data = DB::table('forum_forum')->where('status', 1)->whereIn('fid', [12, 161, 52, 39])->select('fid', 'name')->get();
            return ['top_list' => $data];
        } else {
            $user = Common_member_connect_wechat::where('unionid', $unionid)->first();
            $data2 = DB::table('my_forum')->where('uid', $user->uid)->orderBy('time', 'desc')->get();//用户定义的栏目
            return ['top_list' => $data2];
        }
    }


    /*
   * 论坛版块列表切换
   * */
    public function forum_list2($fid)
    {
        $fids = !empty($fid) ? $fid : $this->forum();
        $time = time();
        $times = $time - 86400 * 30;
        $data = DB::table('forum_thread')
            ->leftJoin('forum_post_previewimg', 'forum_post_previewimg.tid', '=', 'forum_thread.tid')
            ->leftJoin('forum_forum', 'forum_forum.fid', '=', 'forum_thread.fid')
            ->where('forum_thread.fid', $fids)
            ->where('forum_thread.dateline', '>=', $times)//查询30天内的
            ->select('forum_thread.authorid', 'forum_thread.tid',
                'forum_thread.subject',
                'forum_thread.author',
                'forum_thread.views',
                'forum_thread.fid',
                'forum_thread.lastpost',
                'forum_post_previewimg.image',
                'forum_forum.name')
            ->orderBy('forum_thread.dateline', 'desc')
            ->paginate(7);
        foreach ($data as $key => $value) {
            $value->image = json_decode(stripslashes($value->image), true);
        }

        $forum_list2_data = ['forum_list' => $data];
        //加入到缓存
        Cache::put('forum_list2_data', $forum_list2_data, 3600);
        if (Cache::has('forum_list2_data')) {
            return Cache::get('forum_list2_data');//读取
        }

    }


    /*
     * 视频列表
     *
     * */

    public function videoList()
    {
        $data = DB::table('exam_video')->where('is_free', 1)->orderBy('view', 'desc')
            ->select('id', 'createtime', 'name', 'url', 'img', 'view', 'intro')->orderBy('view', 'desc')
            ->paginate(6);
        foreach ($data as $key => $value) {
            $value->createtime = date('Y-m-d H:i:s', $value->createtime);
        }
        $videoList_data = ['videoList' => $data];
        //加入到缓存
        Cache::put('videoList_data', $videoList_data, 3600);
        if (Cache::has('videoList_data')) {
            return Cache::get('videoList_data');//读取
        }
    }


    /*
     * 视频评论提交
     *
     * */
    public function videoComments_put(Request $request)
    {
        if ($request->unionid) {
            $user = Common_member_connect_wechat::where('unionid', $request->unionid)->first();
            $info = DB::connection('mysql2')->table('exam_video_comments')->insert(
                [
                    'video_id' => $request->video_id,//视频id
                    'uid' => $user->uid,//用户id
                    'is_show' => 0,//'是否显示，0：显示，1：不显示',
                    'contents' => mb_convert_encoding($request->contents, "GBK"),//视频内容
                    'time' => time(),//评论时间
                ]);

            if ($info) {
                return ['data' => true, 'error' => "评论成功！"];
            } else {
                return ['data' => false, 'error' => "评论失败！"];
            }
        } else {
            return "参数错误!";
        }
    }


    /*
     * 视频评论查询
     *
     * */
    public function videoComments_get(Request $request)
    {
        $data = DB::table('exam_video_comments')->where('is_show', 0)->where('video_id', $request->video_id)->orderBy('time', 'desc')
            ->leftJoin('common_member_connect_wechat', 'exam_video_comments.uid', '=', 'common_member_connect_wechat.uid')
            ->select(
                'common_member_connect_wechat.nickname',
                'common_member_connect_wechat.avatarurl',
                'exam_video_comments.contents',
                'exam_video_comments.time'
            )->orderBy('exam_video_comments.time', 'desc')
            ->paginate(6);

        foreach ($data as $key => $value) {
            $value->time = date("Y-m-d", $value->time);
        }
        if ($data->first()) {
            return ['videoComments_get' => $data];
        } else {
            return ['error' => "暂时没人评论！"];
        }
    }


    /*
     * 帖子详情'备用',
     * */
    public function pre_forum_post($tid)
    {
        $first_yes = DB::table('forum_post')
            ->leftJoin('common_member_count', 'common_member_count.uid', '=', 'forum_post.authorid')
            ->leftJoin('forum_post_previewimg', 'forum_post_previewimg.tid', '=', 'forum_post.tid')
            ->where('forum_post.tid', $tid)->where('first', 1)
            ->select('forum_post.tid',
                'forum_post.subject',
                'forum_post.author',
                'forum_post.dateline',
                'forum_post.first',
                'common_member_count.views',
                'forum_post.message',
                'forum_post.fid',
                'forum_post_previewimg.image'

            )->get();//首贴


        $first_no = DB::table('forum_post')->where('tid', $tid)->where('first', 0)
            ->select('tid', 'author', 'message', 'first', 'subject', 'fid')
            ->orderBy('dateline', 'desc')
            ->get();//回帖
        //回帖统计
        $data = DB::table('forum_post')->where('tid', $tid)->where('first', 0)->count();


        foreach ($first_yes as $key => $value) {
            $value->image = json_decode(stripslashes($value->image), true);
            $value->dateline = date("Y-m-d", $value->dateline);
            $value->count = $data;


            $value->message = strip_tags($value->message);
            $value->message = preg_replace('/\s|&nbsp;/', '', $value->message);
            $value->message =  preg_replace("/\r\n/",'', $value->message);

            $value->message = preg_replace('/<font[^>]*color:#fff[^>]*>.*<\/font>/isU', '', $value->message);//处理掉不显示的font标签
            $value->message = preg_replace('/下载地址回复可见.*<\/p>/isU', '</p>', $value->message);
            $value->message = strip_tags($value->message, "<a><p><img><table><tbody><tr><th><td><span><script><br>");

            //对message中的表格进行处理,先隐藏
            $value->message = preg_replace('/(<table.*>.*<\/table>)/isU', '<div class="scroll-table" style="display:none;"><div class="scroller">\1</div></div>', $value->message);

            $value->message = preg_replace('/<br[^>]*\/?>(\s*<br[^>]*\/?>)+/is', '<br/>', $value->message);//n个连续<br/>
            $value->message = preg_replace('/<p(.[^>]*)>\s*<br[^>]*\/?>\s*<\/p>/isU', '', $value->message);//<p><br/></p>
            $value->message = preg_replace('/(<p(.[^>]*)>)\s*<br[^>]*\/?>/isU', '\1', $value->message);//<p><br/>
            $value->message = preg_replace('/(<\/p>)\s*<br[^>]*\/?>/isU', '\1', $value->message);//</p><br/>
            $value->message = str_replace('target="_blank"', "", $value->message);
            $value->message = preg_replace('/本帖最后由.*编辑/isU', '', $value->message);//本帖最后由...编辑
            $value->message = str_replace('发自8264手机版 m.8264.com', "", $value->message);


        //对message中引用的处理
            preg_match_all("/<blockquote>(.*)<a.*pid=(\d*)&.*>.*<\/a>(.*)<\/blockquote>/isU", $value->message, $matA);

            if (!empty($matA[2][0])) {
                $post["message_quote_content"] = strip_tags($matA[3][0]);
                $arr = explode(" ", strip_tags($matA[1][0]));
                $post["message_quote_author"]   = $arr[0];
                $post["message_quote_dateline"] = $arr[2]." ".$arr[3];
                $post["message_quote_pid"] 		= $matA[2][0];

                $value->message = preg_replace('/<blockquote>(.*)<\/blockquote>/isU', '', $value->message);//引用
            }

            //解析附件
            preg_match_all('/\[attach\](\d+)\[\/attach\]/isU', $value->message, $matA);
            if ($matA[1]) {
                $aids  = implode(',', $matA[1]);
                $sql = DB::select('select aid, attachment, dir  from pre_forum_attachment where  aid in('.$aids.')and isimage=1');
                foreach ($sql as $key => $val){
                    $pics[$val->aid] = "<img src='http://image1.8264.com/forum/$val->attachment'>";
                }
                foreach ($matA[1] as $k=>$v) {
                    if (isset($pics[$v])) {
                        $value->message = str_replace("[attach]{$v}[/attach]", $pics[$v], $value->message);
                    } else {
                        $value->message = str_replace("[attach]{$v}[/attach]",'', $value->message);
                    }
                }
            }

        }

        return ['post' => $first_yes, 'postList' => $first_no];
    }


}



