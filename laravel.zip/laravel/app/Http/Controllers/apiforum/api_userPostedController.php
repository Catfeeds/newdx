<?php

namespace App\Http\Controllers\apiforum;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Models\Forum_thread;
use App\Http\Models\Forum_post_tableid;
use App\Http\Models\Forum_post;
use App\Http\Models\Common_member_connect_wechat;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;

require_once 'upyun.class.php';

class api_userPostedController extends Controller
{
    public $user_name = '8264coder';//操作员名称
    public $pwd = '8264jianghong';//密码
    public $bucket = 'img8264';//服务器名称

    /*
 * discuz 发帖流程主要分为7个步骤：
     第一步：向 主题表 pre_forum_thread 中插入版块ID、用户ID、用户名、帖子标题、发帖时间等信息。
     第二步：获取第一步插入表 pre_forum_thread 的数据ID，作为主题ID,即 tid
     第三步：向 post 分表协调表 pre_forum_post_tableid 插入一条数据，这张表中只有一个自增字段 pid
     第四步：获取 第三步 插入表 pre_forum_post_tableid 的数据ID，作为 pid
     第五部：向帖子表 pre_forum_post 中插入帖子相关信息，这里需要注意的是： pid为第四部的pid值，tid为第二步的tid值
     第六部：更新版块 pre_forum_forum 相关主题、帖子数量信息
     第七步：更新用户 pre_common_member_count 帖子数量信息
     discuz发帖过程主要就是以上7个步骤，通过这几个步骤就可以完成对实现discuz的发帖流程，其中设计到一些积分等其他信息的可以自己加上。

帖子表：pre_forum_post

　　　　帖子表pid最大值设置表：pre_forum_post_tableid

　　　　帖子列表表：pre_forum_thread

　　　　帖子所在板块表：pre_forum_forum

pre_forum_post 帖子表
pre_forum_thread  主题表
 * */

    /*
     * 用户发帖
     * */

    public function userPublish(Request $request)
    {

        if ($request->unionid) {

            //return $request->callbackImglist;
//第一步
            $user = Common_member_connect_wechat::where('unionid', $request->unionid)->first();
            $info = new Forum_thread;
            $info->fid = $request->fid;
            $info->authorid = $user->uid;//会员id

            $info->author = mb_convert_encoding($user->nickname, "GBK");//会员名
            $info->lastposter = mb_convert_encoding($user->nickname, "GBK");//最后发表人id
            $info->subject = mb_convert_encoding($request->title, "GBK");//帖子标题
            $info->attachment = 0;//附件,0无附件 1普通附件 2有图片附件
            $info->dateline = time();//发表时间
            $info->lastpost = time();//最后发表时间
            $info->status = 224;//位运算存储 0x0000 - FFFF 总共支持16个标志位
            $info->save();

            $info->tid;//得到tid


            //接收图片数组并转换
            foreach ($request->callbackImglist as $key => $value) {
                $pic[]['pic'] = $value;
            }

            if (!empty($pic)) {
                //图片保存到数据库
                DB::table('forum_post_previewimg')->insert([
                    'tid' => $info->tid,
                    'image' => json_encode($pic),
                    'dateline' => time(),
                ]);
            }


            $pinfo = new Forum_post_tableid;
            $pinfo->pid = null;
            $pinfo->save();

            $pinfo->pid;//得到pid

            //保存帖子内容
            $forum_post = new Forum_post;
            $forum_post->fid = $info->fid;
            $forum_post->tid = $info->tid;
            $forum_post->first = 1;//首贴
            $forum_post->author = mb_convert_encoding($user->nickname, "GBK");
            $forum_post->authorid = $user->uid;//会员id
            $forum_post->dateline = time();//发表时间
            $forum_post->subject = mb_convert_encoding($request->title, "GBK");//帖子标题
            $forum_post->message = mb_convert_encoding($request->contents, "GBK");
            $forum_post->useip = $this->getIP();
            if ($forum_post->save()) {
                return "发帖成功!";
            } else {
                return "发帖失败";
            }
        } else {
            return "参数错误!";
        }
    }


    /*
     * 用户发帖图片暂存到本地
     * */

    public function userImg()
    {

        $Path = "/appletImg/";
        if (!empty($_FILES['file'])) {
            //获取扩展名
            $exename = $this->getExeName($_FILES['file']['name']);

            if ($exename != 'png' && $exename != 'jpg' && $exename != 'gif') {
                exit('不允许的扩展名');
            }
            $fileName = base_path() . $Path;//文件路径
            $upload_name = '/img_' . date("YmdHis") . rand(0, 100) . '.' . $exename;//文件名加后缀
            if (!file_exists($fileName)) {
                //进行文件创建
                mkdir($fileName, 0777, true);
            }
            $imageSavePath = $fileName . $upload_name;
            if (move_uploaded_file($_FILES['file']['tmp_name'], $imageSavePath)) {
                $imgPath = $Path . $upload_name;
            }

            return $imgPath;
        }
    }

    public function getExeName($fileName)
    {
        $pathinfo = pathinfo($fileName);
        return strtolower($pathinfo['extension']);
    }


    /*
     *
     * 图片上传到又拍云
     *
     * */

    public function yunImg()
    {

        $picture_path = base_path() . $this->userImg();//本地文件路径
        $upyun = new\ UpYun($this->bucket, $this->user_name, $this->pwd);//new这个方法
        //文件路径及名称
        $file = '/forum/appletImg/' . date('Ymd') . '/' . date("Ymd") . '_' . $this->uuid() . '.png';

        //如果不注释则原图上传
//        $fh = fopen($picture_path, 'rb');
//        $rsp = $upyun->writeFile($file, $fh, True);
//        fclose($fh);
//        var_dump($rsp);
        /***********************************************************************************/
        /*
         * 生成缩略图不保留原图
         * */
        $opts = array(
            \UpYun::X_GMKERL_TYPE => 'square', // 缩略图类型
            \UpYun::X_GMKERL_VALUE => 300, // 缩略图大小
            \UpYun::X_GMKERL_QUALITY => 95, // 缩略图压缩质量
            \UpYun::X_GMKERL_UNSHARP => True // 是否进行锐化处理
        );

        $fh = fopen($picture_path, 'rb');
        $rsp = $upyun->writeFile($file, $fh, True, $opts);   // 上传图片，自动创建目录
        fclose($fh);
        @unlink($picture_path);//上传到又拍云后删除本地临时存储文件
        return "http://image1.8264.com" . $file;
        //var_dump($rsp);
    }

 /*
 * 用户回帖,读写分离
 *
 * */

    public function userReply(Request $request)
    {
        $user = Common_member_connect_wechat::where('unionid', $request->unionid)->first();
        // return $user->uid;
        $info = DB::connection('mysql2')->table('forum_post')->insert(
            [
                'tid' => $request->tid,//帖子id
                'fid' => $request->fid,//板块id
                'first' => 0,//不是首贴
                'author' => mb_convert_encoding($user->nickname, "GBK"), //作者名称
                'authorid' => $user->uid,//作者id
                'message' => mb_convert_encoding($request->message, "GBK"),//帖子内容
                'dateline' => time(),//时间
                'useip' => $this->getIP(),//用户ip
            ]);

        if ($info) {
            return ['data' => true, 'error' => "回帖成功！"];
        } else {
            return ['data' => false, 'error' => "回帖失败！"];
        }
    }


    function uuid()
    {
        $charid = md5(uniqid(mt_rand(), true));
        $hyphen = chr(45);// "-"
        $uuid = substr($charid, 0, 8) . $hyphen
            . substr($charid, 8, 4) . $hyphen
            . substr($charid, 12, 4) . $hyphen
            . substr($charid, 16, 4) . $hyphen
            . substr($charid, 20, 12);
        return $uuid;
    }


    function getIP()
    {
        if (getenv('HTTP_CLIENT_IP')) {
            $ip = getenv('HTTP_CLIENT_IP');
        } elseif (getenv('HTTP_X_FORWARDED_FOR')) { //获取客户端用代理服务器访问时的真实ip 地址
            $ip = getenv('HTTP_X_FORWARDED_FOR');
        } elseif (getenv('HTTP_X_FORWARDED')) {
            $ip = getenv('HTTP_X_FORWARDED');
        } elseif (getenv('HTTP_FORWARDED_FOR')) {
            $ip = getenv('HTTP_FORWARDED_FOR');
        } elseif (getenv('HTTP_FORWARDED')) {
            $ip = getenv('HTTP_FORWARDED');
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }


    /*
     * 帖子点评
     *
     *
                //点评添加的操作
                DB::insert('forum_postcomment', $commentContent);

                //添加点评之后将帖子回复表的comment字段赋值为1，代表该贴有评论,
                DB::update('forum_post', array('comment' => 1), "pid='".$_G['gp_pid']."'");
     * */

    public function postcomment_get(){

    $data= DB::table('pre_forum_postcomment')->where('tid', $request->tid)->where('pid', $request->pid)
        ->select('tid', 'author', 'authorid','comment', 'dateline')
        ->orderBy('dateline', 'desc')
        ->get();//点评
}


    public function postcomment_put(Request $request){



        //先加入到帖子表forum_post再加到pre_forum_postcomment点评帖子表注意对应的pid

//解析附件



}




}
