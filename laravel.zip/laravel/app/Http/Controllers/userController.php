<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Common_member_connect_wechat;//微信登陆模型
use Illuminate\Http\Request;
use App\Http\Requests;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;//加载缓存
class userController extends Controller
{

    public function index(){


        $results = DB::select('select * from pre_common_member_connect_wechat limit 10');

        return $results;

}

}