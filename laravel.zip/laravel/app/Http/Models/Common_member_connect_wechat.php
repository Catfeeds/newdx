<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Http\Requests;
use Illuminate\Support\Facades\DB;

require_once 'WXBizDataCrypt.class.php';

class Common_member_connect_wechat extends Model
{
    protected $table = 'common_member_connect_wechat';
    protected $primaryKey = 'unionid';
    public $timestamps = false;//打开为去掉时间戳

    public $appid = "wxbf05707467d24004";
    public $secret = "93a46a0f87b0155d938abab9dcb57095";

    /*
    *是否有记录登录信息
    */
    public function isLogin($unionId)
    {

        return Common_member_connect_wechat::where('unionid', $unionId)->first();

    }

    //获取用户的openId和session_key
    public function authorization()
    {
        $code = $_GET["code"];
        $URL = "https://api.weixin.qq.com/sns/jscode2session?appid=$this->appid&secret=$this->secret&js_code=$code&grant_type=authorization_code";
        if (false !== $apiData = json_decode(file_get_contents($URL), true)) {
            return $apiData;
        }
        return false;
    }

    //用户登录,判断用户是否被存入getSession，如果没有则走获取过程并存入Session
    public function login()
    {
        //调用获取用户的openId和session_key方法
        if ((false !== $apiData = $this->authorization()) && !isset($apiData['errcode'])) {

            $sessionKey = $apiData['session_key'];
            $userifo = new \WXBizDataCrypt($this->appid, $sessionKey);
            $encryptedData = $_GET["encryptedData"];//微信小程序传过来的
            $iv = $_GET["iv"];//微信小程序传过来的
            $errCode = $userifo->decryptData($encryptedData, $iv, $data);
            if ($errCode == 0) {
                return json_decode($data, true);
            } else {
                return false;
            }
        }
        return false;
    }


    //如果用户不存在去执行这里注册
    public function createUser($userInfo)
    {
        $user_member = new Common_member;
        $user_member->username =uniqid("wx");//生成唯一用户名
        $user_member->password = md5(uniqid());
        $user_member->regdate = time();
        $user_member->telephone = 0;
        $user_member->timeoffset = 999;//时区校正
        if (true === $user_member->save()) {
            //先放入会员表再放入判断表;注意不能每个字段不能重复.
            DB::connection('mysql2')->table('common_member_connect_wechat')->insert(
                [
                    'uid' => $user_member->uid,
                    'unionid' => $userInfo['unionId'],
                    'openid' => 'ohR_' . $userInfo['openId'],
                    'nickname' =>mb_convert_encoding($userInfo['nickName'], "GBK"),
                    'avatarurl' => $userInfo['avatarUrl'],
                    'bind_time' => time(),
                    'scope'=>0,
                    'access_token'=>0,
                    'access_time'=>0,
                    'refresh_token'=>0,
                    'refresh_time'=>0
                ]);

            DB::table('common_member_connect_wechat')->where('uid', $user_member->uid)->get();
            return $this->geuUer($user_member->uid);
        };
        return false;
    }


    /*
 * 从数据库获取用户信息
*/
    public function geuUer($uid)
    {

        $userData = DB::table('common_member')->where('common_member.uid', $uid)
            ->leftJoin('common_member_connect_wechat', 'common_member.uid', '=', 'common_member_connect_wechat.uid')
            ->select('common_member_connect_wechat.unionid', 'common_member_connect_wechat.nickname','common_member_connect_wechat.avatarurl')
            ->get();
        if($userData){//有数据
            return $userData;
        }else{//没数据
            //DB::table('common_member_connect_wechat')->where('uid', $uid)->delete();
            return "获取信息出错，请重试！";
        }
    }

}
