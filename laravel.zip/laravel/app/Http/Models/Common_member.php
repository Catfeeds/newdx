<?php

namespace App\Http\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Http\Requests;

class Common_member extends Model
{
    protected $table = 'common_member';
    protected $primaryKey = 'uid';
    public $timestamps=false;//打开为去掉时间戳

    //protected $guarded = [];//不能填写的字段
    //protected $fillable = ['Name','Password'];//可以填写的字段
   

}
