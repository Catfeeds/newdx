<?php

namespace App\Http\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Http\Requests;

class Forum_post_tableid extends Model
{
    protected $table = 'forum_post_tableid';
    protected $primaryKey = 'pid';
    public $timestamps=false;//打开为去掉时间戳

    //protected $guarded = [];//不能填写的字段
    //protected $fillable = ['Name','Password'];//可以填写的字段
   

}
