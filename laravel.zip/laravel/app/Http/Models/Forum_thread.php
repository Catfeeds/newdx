<?php

namespace App\Http\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Http\Requests;

//require_once 'WXBizDataCrypt.class.php';

class Forum_thread extends Model
{
    //这里链接的是写入数据库
    protected $connection = 'mysql2';
    protected $table = 'forum_thread';
    protected $primaryKey = 'tid';
    public $timestamps=false;//打开为去掉时间戳

    //protected $guarded = [];//不能填写的字段
    //protected $fillable = ['Name','Password'];//可以填写的字段

}
